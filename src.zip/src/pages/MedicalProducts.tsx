

export const medicalProducts = [
  
  {
    id: "med-1",
    title: "Central Venous Catheter Kit",
    Description: [
      "Central Venous Catheter made of specially formulated and biocompatible Polyurethane material provides strength during insertion and also softens at body temperature to conform to the body tissues and reduces the risk and vascular trauma",
      "Specially Designed Soft & beveled tip for smooth & easy insertion of catheter",
      "Soft Flexible J-Tip Guide wire prevents the vessel perforation and also provides good torque to ensure film insertion",
      "Sufficiently radio-Opaque material of catheter with clear, definite marking facilitates correct placement of catheter tip",
      "Kink resistant Guidewire with soft & flexible J-tip offers better torque which helps in easy insertion & prevents vessel perforation",
      "Wires are Double Distal",
      "2 piece design of guidewire advancer. Sterile / Disposable / Individually Tray Packed"
    ],
    Completeset: [
      "Indwelling catheter",
      "Y-Introducer needle with check valve",
      "J-Tip guide wire",
      "Vessel dilator",
      "Luer lock syrings",
      "Scalpel",
      "Catheter holder",
      "Catheter holder clamp",
      "Injection cap",
      "Extension Line Clamp",
      "Guiding Syringe / LOR Syringe (Optional)"
    ],
    image: "/placeholder.svg",
    category: "medical" as const,
  },
  {
    id: "med-2",
    title: "Hemodialysis Catheter Kit",
    Description: [
      "Polyurethane material",
      "Soft, geometrically designed conical tip to ensure easy insertion and prevent catheter related trauma",
      "Hemodialysis catheter are single/double/multiple lumen catheter that provides temporary vascular access for hemodialysis until a permanent access is available or until another type of dialysis therapy is substituted",
      "The multiple lumen catheter contains two large bore lumens that are connected to the dialysis machine to form a complete circuit for the removal and return of the patient's blood during treatment",
      "Clear silicon lumen extensions for enhanced visibility and safety. Sterile / Disposable / Individually Tray Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Central Venous Access & Dialysis"
  },
  {
    id: "med-3",
    title: "Blood Tubing Set",
    Description: [
      "Medical grade PVC tubing for higher bio-compatibility",
      "Advantage of built-in Heparin and Saline line",
      "Extra corporeal blood circuit tubing set, used during dialysis",
      "Low Priming Volume",
      "Easy of use",
      "Customised blood tubing set as per clinic protocol and for different dialysis machines are available",
      "Injection Site : Large finger guard",
      "Drip Chamber : Available Various diameter sizes",
      "Clamp : Clamps to secure blocking performance. Sterile /Disposable/ Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Central Venous Access & Dialysis"
  },
 {
  id: "med-4",
  title: "Peritoneal Transfusion Dialysis Kit",
  Description: [
    "Suitable for performing peritoneal dialysis in patients of all age groups",
    "Perforated open-end catheter manufactured from polypropylene",
    "Stainless steel trocar is provided to facilitate smooth penetration",
    "Scalpel blade is provided for the incision",
    "The trocar and the tip of the catheter are perfectly matched to facilitate trauma free insertion",
    "Latex flash bulb is provided on the junction unit for additional medication",
    "Sizes : Adult, Child. Sterile /Disposable/ Individually Packed"
  ],
  Completeset: [],
  image: "/placeholder.svg",
  category: "Central Venous Access & Dialysis"
},

  {
    id: "med-5",
    title: "Peritoneal Transfusion Dialysis Set",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flow rate",
      "Clear Transparent & Flexible built in Chamber with sharp and easy piercing Spike",
      "Special designed for 'Y' shaped transfusion set for administrating dialysis solution",
      "Provided with two upper control clamp to facilitate the attractive change of solution bottles",
      "Top lower control clamps help for easy input and drainage of solutions. Sterile /Disposable/ Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Central Venous Access & Dialysis"
  },
  {
    id: "med-6",
    title: "A.V. Fistula Needle",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flow rate",
      "To connect blood lines of the blood vessels through needles when dialysis is carried out through an internal fistula",
      "Back eye needle to minimize interruption of blood flow",
      "Siliconised ultra thin walled & sharp beveled needle to minimize trauma to the patient",
      "Flexible butterfly wing for proper fixation",
      "Color coded wing for easy identification of sizes as per standard",
      "Also available in Twin pack"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Central Venous Access & Dialysis"
  },
  {
    id: "med-7",
    title: "Infusion Set",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flow rate",
      "Clear, Transparent & Flexible Drip Chamber with sharp and easy piercing Spike",
      "Smooth Roller Clamp Facilitates easy, safe control and adjustment of fluid rates",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Infusion & Transfusion"
  },
  {
    id: "med-8",
    title: "Blood Donor Sets",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flow rate",
      "Smooth Roller Clamp Facilitates easy, safe control and adjustment of fluid rates",
      "Needle size G: 16. extra sharp needle for smooth and effortless vein puncture",
      "Sterile / Disposable / Individually Packed",
      "Ideal sharpness for less pain and more comfort",
      "Advanced Uni-Body design"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Infusion & Transfusion"
  },
  {
    id: "med-9",
    title: "Insulin Syringe",
    Description: [
      "Ideal sharpness for less pain and more comfort",
      "Advanced Uni-Body design",
      "Low dead space design ensures dosage accuracy and minimum wastage of drugs",
      "Clear transparent barrel and bold marking facilitates proper drug delivery",
      "Needles have ultra thin wall permitting rapid and efficient delivery. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Infusion & Transfusion"
  },
  {
    id: "med-10",
    title: "Safety IV Cannula",
    Description: [
      "Passive fully automatic protection",
      "Needle sharp tip is enclosed inside a plastic cage after pulling out",
      "The plastic cage is designed as such that once needle sharp tip is fully enclosed inside it cannot come out of the cage hence prevents",
      "Healthcare professionals from the risk of accident due to needle stick injury of injection",
      "The size of Safety I.V. Cannula is very similar to conventional I.V. Cannula and the technique of cannulation is similar to cannulation technic of conventional I.V. Cannula",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Infusion & Transfusion"
  },
  {
    id: "med-11",
    title: "Scalp Vein Set",
    Description: [
      "Butterfly set for long term infusion",
      "Scalp vein set is designed to provide rapid venous access with greater patient comfort during infusion",
      "Short beveled siliconized needle facilitates atraumatic cannulation",
      "Thin wall needle provides better flow rate per gauge",
      "Butterfly shaped wings facilitate easy handling and attachment with the skin",
      "The proximal end of the set is provided with flexible female luer fitting",
      "Butterflies are color coded for instant identification of needle size",
      "Butterfly is connected to soft non toxic, non-irritant, medical grade tube",
      "Available with DEHP Free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Infusion & Transfusion"
  },
  {
    id: "med-12",
    title: "Extension Tube",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flow rate",
      "Male luer lock connector at one end and female luer lock connector at other end",
      "Available with DEHP Free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Infusion & Transfusion"
  },
  {
    id: "med-13",
    title: "Three Way Stopcock",
    Description: [
      "Fully transparent polycarbonate body for visualization of flow",
      "6% luer taper as per International Standard",
      "Arrow indication marks for indicating direction of flow",
      "Also available with lipid resistant feature",
      "Rotating dead space for accurate drug administration",
      "Continuous flow channels",
      "Tight covers for all ends",
      "Pressure tested hydrostatically for up to 60 PSI",
      "Rotation allowed for 360 degree",
      "Red & blue pegs for arterial and venous line identification, available on request",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Infusion & Transfusion"
  },
  {
    id: "med-14",
    title: "Pressure Monitoring Line",
    Description: [
      "Used for high pressure monitoring, and connection between syringe infusion pump and patient",
      "Provided with universal male luer lock and female luer lock at either end",
      "Available with DEHP Free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Infusion & Transfusion"
  },
  {
    id: "med-15",
    title: "Injection Stopper",
    Description: [
      "Thread stopper with injection site used to stop leakage when connected to infusion devices",
      "Also used for extra medication along with infusion",
      "Universal 6% Taper as per ISO 594, compatible with any standard product",
      "Latex Free plug with leakage free fitting for flushing catheter or drawing blood samples",
      "Minimal dead space",
      "Sterile / Disposable / Individually packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Infusion & Transfusion"
  },
  {
    id: "med-16",
    title: "Blood Transfusion Sets",
    Description: [
      "For transfusion of blood or blood components",
      "Super smooth kink resistance tubing ensures uniform flow rate",
      "Clear, Transparent & Flexible Drip Chamber with sharp and easy piercing Spike",
      "With 200 micron blood filter",
      "Smooth Roller Clamp Facilitates easy, safe control and adjustment of fluid rates",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Infusion & Transfusion"
  },
  {
    id: "med-17",
    title: "Disposable Syringe",
    Description: [
      "Transparent barrel allows easy measurement",
      "Thermoplastic Elastomer (TPE) Gasket ensures smooth movement",
      "High accuracy moulds ensure consistent quality",
      "Imported Cannula with precise sharpness and strong bonding",
      "Ultra thin wall needles allow efficient drug delivery",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Infusion & Transfusion"
  },
  {
    id: "med-18",
    title: "IV Cannula",
    Description: [
      "Flash back chamber for quick visualization of venous return",
      "Wings for easy gripping and safe clamping",
      "Needle cover prevents accidental damage",
      "Color coded body/port cap as per ISO Standard",
      "Triple point Needle for painless insertion",
      "Transparent Teflon catheter with Radio-opaque strip",
      "Automated Tipping Technology for smooth penetration",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Infusion & Transfusion"
  },
  {
    id: "med-19",
    title: "IV Cannula Fixator",
    Description: [
      "Used for Fixation of I.V Cannula / Catheter",
      "Made from Thin Polyurethane film - Transparent or Non-woven",
      "Breathable and waterproof",
      "Reinforced notches reduce mechanical stress",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Infusion & Transfusion"
  },
  {
    id: "med-20",
    title: "Measured Volume Burette Set",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flow rate",
      "Flexible, Transparent & soft cylindrical chamber",
      "Smooth Roller Clamp for fluid rate adjustment",
      "Floating auto shut off valve to prevent air trapping",
      "Separate plug for extra medication",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Infusion & Transfusion"
  },



  {
    id: "med-21",
    title: "IV Flow Regulater",
    Description: [
      "I.V. Fluid Flow Regulator Extension Set to regulate the flow of IV fluid from an infusion set into an IV catheter",
      "Super smooth kink resistance tubing ensures uniform flow rate",
      "Designed to control flow rate from 5ml / hr - 250 ml / hr manually",
      "Built-on \"Y\" Connector Injection site for extra Medication",
      "Two hand operation eliminates the danger of accidental tampering",
      "Provision of male and female luer lock makes it compatible with other devices",
      "Available with DEHP Free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Infusion & Transfusion"
  },
  {
    id: "med-22",
    title: "Three Way Stopcock With Extension Tube",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flow rate",
      "Extension line with three way stop cock at one end & male luer lock connector at other end",
      "Crystal clear transparent channel",
      "Minimum priming volume required for accurate drug administration",
      "Arrow indication on the handle to indicate the direction of flow",
      "Connection meets 6% taper requirement to ensure leakage free fitment",
      "Available with DEHP Free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Infusion & Transfusion"
  },
  {
    id: "med-23",
    title: "Luer Lock",
    Description: [
      "Luer Lock is the thread stopper used to stop leakage when connected to infusion devices",
      "White color luer lock",
      "Sterile / Disposable / Individually packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Infusion & Transfusion"
  },
  {
    id: "med-24",
    title: "CVP Manometer",
    Description: [
      "Specially designed to measure and monitor continuous or intermittent, central venous pressure",
      "Manometer tube with graduations marked from - 4 cm to +34 cm and attached to threeway stopcock",
      "120 cm long extension tube is fitted with female luer lock on one end and male luer lock on the other end for safe connection to Central Venous Catheter",
      "Sliding indicator is provided to record reading",
      "Moulded clamps with rubber strings are provided for fixation to IV stand",
      "Y Injection site/Latex OR Latex free rubber flash bulb is provided for extra medication",
      "Sterile / Disposable / Individually packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Infusion & Transfusion"
  },
  {
    id: "med-25",
    title: "Urine Collection Bag",
    Description: [
      "Urine Drainage system for short as well as long term Use",
      "Super smooth kind resistance tube provided with universal tapered connector",
      "Specialty designed hook or hanger facilities for carrying, handling and holding the tube in upright position",
      "Efficient non return valve prevents the back flow",
      "Drainage Outlet System",
      "Bag graduated in ml to indicate the quantity of urine collected",
      "Transparent sheeting allows visual inspection"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Urology"
  },
  {
    id: "med-26",
    title: "Paediatric Urine Collecting Bag",
    Description: [
      "For short term Urine collection",
      "Use of hygiene adhesive for fixation minimum risk of allergy and injuries",
      "Size : 100 ML, 200 ML. Sterile or Non Sterile"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Urology"
  },
  {
    id: "med-27",
    title: "Nelaton Catheter",
    Description: [
      "Nelaton catheters are used for short term bladder catheterization",
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Atraumatic, soft rounded, closed tip with two lateral eyes for efficient drainage",
      "Frozen surface tubing for super smooth intubation",
      "Proximal end is fitted with universal funnel shaped connector for extension",
      "Color coded connectors for easy identification of size as per standards",
      "X-Ray opaque line provided through out the length of catheter",
      "Available in Male & Female Version",
      "Available with DEHP Free Material",
      "Length : 40cm. Sterile / Disposable / Individually Packed"
    ],
     Completeset: [],
    image: "/placeholder.svg",
    category: "Urology"
  },
  {
    id: "med-28",
    title: "Foley Balloon Catheter Latex",
    Description: [
      "Used for short/long term urine drainage",
      "Made from natural latex rubber",
      "Silicon elastomer coated smooth surface for atraumatic catheterization",
      "High strength polymer layer in the middle layer of the catheter ensures wider inner diameter and hence high flow rate",
      "Minimizes encrustation and subsequent catheter blockage and failure",
      "Smooth eye, ultra thin highly elastic balloon and hard non-return valve for trouble free inflation and deflation",
      "Coned distal end provided with burr free eyes for atraumatic intubation",
      "Hard valve ensures easy inflation and deflation of balloon. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Urology"
  },
  {
    id: "med-29",
    title: "Male External Catheter",
    Description: [
      "Manufactured from pure latex for soft and gentle feel",
      "Male catheter is specially designed for urine incontinence for day and night use in male patient",
      "Provided with self adhesive coated strip for proper fixing on to the penis",
      "Proximal end is designed for easy connection to urine bag, making it simple to use. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Urology"
  },
  {
    id: "med-30",
    title: "Rectal Catheter",
    Description: [
      "For introduction of enema solution into rectum to release/aspire rectal fluid",
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Atraumatic, soft rounded, closed tip with two lateral eyes for efficient drainage",
      "Frozen surface tubing for super smooth intubation",
      "Proximal end is fitted with universal funnel shaped connector for extension",
      "Color coded plain connector for easy identification of size",
      "Length: 40cm. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Urology"
  },

  
  {
    id: "med-31",
    title: "Double J Stent",
    Description: [
      "D. J. Stent used for temporary internal drainage from ureteropelvic junction to the bladder",
      "Made of superior grade poly-urethane material",
      "Black line on the stent indicates the direction of coil after withdrawal of guide wire",
      "Complete radio opaque stent for x-ray visualization. Implant tested with an externally low encrustation tendency",
      "Ureteral Stent Consist: Stent, Pusher, with or without Thread",
      "Ureteral Stent Kit Consist: Stent, Pusher, Guidewire, 2 Clamps with or without Thread",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Urology"
  },
  {
    id: "med-32",
    title: "Leg Urine Collection Bag",
    Description: [
      "Super smooth kink resistance tube provided with universal tapered connector",
      "Provides freedom of mobility as the bag is attached to the leg of the patient",
      "Efficient non return valve prevents the back flow",
      "Bottom Outlet Drainage System",
      "Bag graduated in ml to indicate the quantity of urine collected",
      "Transparent sheeting allows visual inspection",
      "Size : 800mI. Tube length : 50cm, 80cm, 100cm. Sterile or Non-Sterile"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Urology"
  },
  {
    id: "med-33",
    title: "Urine Collecting Bag With Measured Volume Chamber",
    Description: [
      "Super smooth kink resistance tube provided with universal tapered connector",
      "Designed for accurate measurement of hourly urine output during examination of the patient",
      "Urine Bag is manufactured from eXtra strong sheeting to withstand during the long period",
      "Specially designed hook facilities for carrying, handling and holding the tube in upright position",
      "Urine bag attached directly with measured volume meter ensures auto over flow and convenience to empty the measured volume meter in the bag",
      "Completely closed circuit eliminates the risk of contamination",
      "With \"T\" Type Bottom Outlet",
      "Bag graduated in ml to indicate the quantity of urine collected",
      "Transparent sheeting allows visual inspection",
      "Available with DEHP Free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Urology"
  },
  {
    id: "med-34",
    title: "TUR Set",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "\"Y\" shaped set for endoscopic irrigation during trans uretheral resection of prostate gland",
      "Thumb operated clamps, help quick and smooth changeover of bottles",
      "Proximal end fitted with flexible latex tubing for easy connection to endoscope. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Urology"
  },
  {
    id: "med-35",
    title: "Foley Balloon Catheter",
    Description: [
      "100 % Medical grade silicone for Superior Biocompatibility",
      "Used for long term urine drainage-Transparent medical grade silicone tube allows easy visual inspection and fluid observation",
      "Non-toxic, bio-compatible and extra smooth for maximum patient comfort",
      "Symmetrical balloon, rounded sealed tip and hard non-return",
      "X-ray opaque line allows for confirmation of intubated tube using X-ray",
      "Soft and uniformly inflated balloon mal‹es the tube sit well against the bladder",
      "Smooth round shaft can minimize trauma during insertion and withdrawal. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Urology"
  },
  {
    id: "med-36",
    title: "Female Catheter",
    Description: [
      "For Short term bladder catheterization through urethra in female",
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Atraumatic, soft rounded, closed tip with two lateral eyes for efficient drainage",
      "frozen surface tubing for super smooth intubation",
      "Proximal end is fitted with universal funnel shaped connector for extension",
      "Color coded connectors for easy identification of size as per standards",
      "X-Ray opaque line provided through out the length of catheter. Length : 20cm. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Urology"
  },
  {
    id: "med-37",
    title: "Urethral Catheter",
    Description: [
      "Used for short-term bladder catheterization through urethra",
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Atraumatic, soft rounded, closed tip with two lateral eyes for efficient drainage",
      "Frozen surface tubing for super smooth intubation",
      "Proximal end is fitted with universal funnel shaped connector for extension. Color coded plain connector for easy identification of size",
      "X-Ray opaque line provided through out the length of catheter",
      "Length: 40cm. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Urology"
  },
  {
    id: "med-38",
    title: "Twins Bore Nasal Oxygen Set",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Designed for easy administration of oxygen and comfort of patient",
      "Soft twin prong nasal tips to ensure equal, volume of oxygen to both air passages",
      "Star lumen main tube to avoid accidental blockage",
      "Smoothly finished and adjustable nasal tips for maximum patient comfort",
      "Soft funnel shaped connector facilitates easy connection to oxygen source",
      "Tube Length : 210 cm",
      "Size : Adult, Paediatric & Neonatal",
      "Available with DEHP free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-39",
    title: "Nasal Oxygen Catheter",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Suitable for direct administration of oxygen via nasopharyngeal route Atraumatic, soft rounded. Open Distal end with two lateral eyes for non-traumatic insertion and dispersion of oxygen and prevention of oxygen burn",
      "Frozen surface tubing for super smooth intubation",
      "Proximal end is fitted with universal funnel shaped connector for connection to oxygen source",
      "Color coded plain connector for easy identification of size",
      "Available with DEHP free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-40",
    title: "Oxygen Mask",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Made from a soft dear plastic and are anatomically formed for comfort",
      "Smooth and feathered edge of face mask for patient comfort and reducing irritation points",
      "Adjustable elastic strip and integrated nose clip for proper positioning of mask",
      "Proximal end of tube is connected with funnel shape connector for easy connection with oxygen source",
      "Star lumen main tube to avoid accidental blockage",
      "Tube Length : 210cm",
      "Size : Adult, Paediatric & Neonatal"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-41",
    title: "Guedel Airways",
    Description: [
      "Suitable for maintaining an unobstructed oropharyngeal airway during general anaesthesia and in unconscious patients",
      "Bite block to prevent biting of tongue and airway occlusion",
      "Rounded atraumatic edges",
      "Smooth airway path for easy cleaning",
      "Color coded Bite Blocks for easy identification of sizes. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-42",
    title: "Suction Catheter With Thumb Control",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "For removal of secretion from trachea and bronchial region",
      "Atraumatic, soft rounded, Open Distal end with one lateral eyes for non-traumatic insertion",
      "Frozen surface tubing for super smooth intubation",
      "Proximal end is fitted with universal funnel shaped connector for extension",
      "Color coded plain connector for easy identification of size",
      "Available with DEHP free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-43",
    title: "Suction Catheter (Thumb Control With Stopper)",
    Description: [
      "Suction Catheter with Thumb Control valve provided with stopper"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-44",
    title: "Suction Catheter With Fingertip Control",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "For removal of secretion from trachea and bronchial region",
      "Atraumatic, soft rounded, Open Distal end with one lateral eyes for non-traumatic insertion",
      "Frozen surface tubing for super smooth intubation",
      "Proximal end is fitted with universal funnel shaped connector for extension",
      "Color coded plain connector for easy identification of size",
      "Available with DEHP free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-45",
    title: "Suction Catheter (Fingertip)",
    Description: [
      "Provided with universal funnel shape connector for safe connection to standard suction equipment"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-46",
    title: "Suction Catheter Plain",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "For removal of secretion from trachea and bronchial region",
      "Atraumatic, soft rounded, Open Distal end with one lateral eyes for non-traumatic insertion",
      "Frozen surface tubing for super smooth intubation",
      "Proximal end is fitted with universal funnel shaped connector for extension",
      "Color coded plain connector for easy identification of size",
      "Available with DEHP free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-47",
    title: "Suction Catheter Plain",
    Description: [
      "Provided with universal funnel shape connector for safe connection to standard suction equipment"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-48",
    title: "Endotracheal Tube Cuffed & Plain",
    Description: [
      "Used to maintain a patent airway and mechanically ventilate patients",
      "High volume, low pressure cuff, maintains seal throughout ventilator cycle",
      "X-ray detective line available",
      "Thermosensitive PVC allows the tube to soften at body temperature to conform to airway anatomy",
      "Clear PVC tube with visible markings for easy observation",
      "Murphy Eye smoothly formed to allows ventilation in the event of obstruction of the end of the tube during intubation",
      "A full range of standard sized to meet most of your requirements",
      "Universal 15 mm Connector at proximal end",
      "Available with DEHP free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-49",
    title: "Reinforced Cuffed & Plain",
    Description: [
      "Used to maintain a patent airway and mechanically ventilate patients",
      "Uniform spiral metal-reinforced tube wall to prevent the tube from kinking",
      "Reinforcement supports tube position and verification during X-ray",
      "Accurate and safe positioning ensured by graduation marks and tip-to-tip radiopaque line",
      "High volume / low pressure cuff ensures efficient low pressure cuff seal (For cuffed tubes)",
      "Universal 15 mm connecter at proximal end",
      "Available with DEHP free Material",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-50",
    title: "L.P.Spinal Needle",
    Description: [
      "Spinal needle provided exceptional control when penetrating the dura",
      "Suitable for spinal anaesthesia",
      "Aggressive anesthetic distribution upon injection. High flow rate enables faster cerebra spinal (CSF) flashback",
      "Clear polycarbonate hub offer easy visualization of CSF or blood",
      "Available with Customized Needle Length. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-51",
    title: "Nebulizer Mask",
    Description: [
      "Designed to be used with any standard Nebulizer kit",
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Smooth and feathered edge of face mask for patient comfort and reducing irritation points",
      "Adjustable elastic strip and integrated nose clip for proper positioning of mask",
      "The Nebulizer Kit just plugs into the standard fitting located at the bottom of the Mask",
      "Masks are designed to deliver more medication directly to the patient due to the direct flow design",
      "Proximal end of tube is connected with funnel shape connector for easy connection with oxygen source",
      "Star lumen main tube to avoid accidental blockage",
      "Tube Length : 210cm",
      "Size : Adult, Paediatric & Neonatal"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-52",
    title: "Multiflow Venturi Mask",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Smooth and feathered edge of face mask for patient comfort and reducing irritation points",
      "Adjustable elastic strip and integrated nose clip for proper positioning of mask",
      "Multiflow Venturi masks are devices that are constructed to supply oxygen or other gases to an individual",
      "Masks fit snugly over the nose and mouth, and are equipped with 6 different oxygen concentration diluters which allows to select different oxygen concentration accordingly, and a tube that connects the oxygen mask to a storage tank where the oxygen is contained, to be connected to central oxygen supplying system in different hospitals",
      "Proximal end of tube is connected with funnel shape connector for easy connection with oxygen source",
      "Star lumen main tube to avoid accidental blockage",
      "Tube Length : 210cm",
      "Size : Adult, Paediatric & Neonatal",
      "Available with DEHP free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-53",
    title: "Single Dial Venturi Mask",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flowrate. Smooth and feathered edge of face mask for patient comfort and reducing irritation points",
      "Adjustable elastic strip and integrated nose clip for proper positioning of mask",
      "Single Dial Venturi masks are devices that are constructed to supply oxygen or other gases to an individual",
      "There are two Oxygen diluters, one(White) for 24%, 26%, 28% and 30%,while the other (Green) is for 35%, 40% or 50%. The appropriate percentage of Oxygen can be selected setting by the indicator of the diluter",
      "Transparent (green or white) plastic masks also leave the face visible, allowing care providers to better ascertain patients' conditions",
      "Proximal end of tube is connected with funnel shape connector for easy connection with oxygen source",
      "Star lumen main tube to avoid accidental blockage",
      "Tube Length : 210cm",
      "Size : Adult & Paediatric",
      "Available with DEHP free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-54",
    title: "High Concentration Oxygen Mask",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Smooth and feathered edge of face mask for patient comfort and reducing irritation points",
      "High concentration Oxygen mask with tubing is intended to supply oxygen or other gases to an Individual for oxygen therapy, and the reservoir bag is able to avoid rebreathing",
      "Proximal end of tube is connected with funnel shape connector for easy connection with oxygen source",
      "Star lumen main tube to avoid accidental blockage",
      "Tube Length : 210cm",
      "Size : Adult & Paediatric",
      "Available with DEHP free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-55",
    title: "T Oxygenator",
    Description: [
      "T-Piece Kit Designed for use in recovery for the delivery of Oxygen via the patient 15mm ET Connection or Laryngeal mask",
      "7.6mm port for suction with non-popping cap",
      "The kit comprises T-piece with port, 22mm -15 cm reservoir flex tube and Oxygen stem with cap. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-56",
    title: "T-Pc. For Nebulizer",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Smooth and feathered edge of face mask for patient comfort and reducing irritation points",
      "Quick to assemble - Facilitates fast nebulisation",
      "Can be used with Mask, iGel, LMA and ET tube",
      "Rotatable sections - Can be used on patients in sitting or supine position",
      "Drug dosages and oxygen flow rates remain as per guidelines",
      "Proximal end of tube is connected with funnel shape connector for easy connection with oxygen source",
      "Star lumen main tube to avoid accidental blockage",
      "Tube Length : 210cm",
      "Size : Adult, Paediatric & Neonatal",
      "Available with DEHP free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-57",
    title: "Catheter Mount",
    Description: [
      "Catheter Mount connects patient ET to breathing circuit. This minimizes the jerk of breathing to ET or TT reducing trauma to trachea",
      "The double swivel makes no dragging on breathing circuit & ET or TT",
      "Light weight, Double swivel rotates 360° on both axis, Minimum compliance, Low dead",
      "Compatible with all types of breathing and ventilator circuits",
      "Provided with 22 mm standard female connector on both the ends with inner diameter of 15 mm",
      "Collapsible corrugated tubing being inert to all anesthetic gases and reagents",
      "An elbow port is provided for easy suctioning without causing disturbance to breathing circuits",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-58",
    title: "Bain Circuits",
    Description: [
      "Bain Circuit offered comprises co-axial modification of basic T-piece system which has been developed for facilitating scavenging of waste anesthetic gases",
      "As a tube carrying fresh gas, it travels inside outer reservoir tube to endotracheal tube connector",
      "The process includes patient inspiring fresh gas from the outer reservoir tube and expiring into reservoir tube",
      "Adult: It is based on Mapleson D system, provided with 22 mm corrugated tube, expiratory valve and 2 litre antistatic bag",
      "Pediatric : It is based on Mapleson F system, provided with 15 & 10 mm corrugated tube with a 0.5 Itr antistatic Rebreathing Bag and a bag bleed valve",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-59",
    title: "Ventilator Circuits",
    Description: [
      "Ventilator Circuit is the gas pathway connecting patients lung to the mechanical ventilator, it is essential that Circuit should be highest quality in order to ventilate patient correctly, efficiently and safely. We offers wide range of circuit with ISO standard connectors to suit most of the ventilator and humidifier",
      "The corrugated tubes have a good flexibility and bending resistance, not meander, not broken, that mechanical ventilation in the process smooth gas supply",
      "Breathing Circuit uses standard connector that is simple convenience in clinic",
      "Size : Adult, Paediatric & Neonatal. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-60",
    title: "Breathing Filters",
    Description: [
      "Breathing Filters are used in respiratory support equipment such as life support and human ventilation machine, fitted in the airway between equipment and patient. The removal of bacteria from the air breathed in the hospital environment is critical in the protection of the patients, other hospital personnel and breathing support equipment Filters utilize hydrophobic membrane & synthetic media that provide barrier & electrostatic filtration with bacterial & vital removal efficiency higher than 99.99% accomplished with extremely low resistance to airflow. The HMW Keeps moisture retention and warming of inhaled air, filter design in different sizes with C02 monitoring port, facilitate use one wider range of patients",
      "Products features: Clear housing. Low flow resistance High filtration efficiency. High heat & humidity level, C02 Mentoring level. Port Sterile package",
      "Size: Adult, Paediatric",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-61",
    title: "Tracheostomy Tube",
    Description: [
      "Used to maintain a patent airway through tracheostomy and mechanically ventilate patients",
      "Kink resistant, thin-walled, thermo-sensitive tube, softens at body temperature",
      "Lockable obturator with facility to insert guide wires to facilitate intubation using the widely accepted Seldinger guide wire technique",
      "Anatomically designed tube and obturator with extra smooth and curved distal end for atraumatic intubation and extubating",
      "Smooth inside / outside surface for ease in intubation, extubating and suctioning",
      "Kink resistant inflation tube to ensure patient safety during cuff inflation and deflation",
      "Radio opaque line and markings provided to facilitate identification of tube position",
      "Universal 15 mm connecter at proximal end",
      "Available with DEHP free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-62",
    title: "Nasopharyngeal Airways",
    Description: [
      "Used to secure and open airways for patients in case of emergencies",
      "Anatomically designed with smooth round edges, thin wall and kink resistance for maximum patient comfort",
      "Available with DEHP free Material",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-63",
    title: "PVC Laryngeal Mask",
    Description: [
      "Supraglottic, non-invasive airway management device",
      "Anatomically engineered mask provided with separate inflation line",
      "Provided with universal 15 mm connector",
      "Radio opaque line for X-ray visualization",
      "Marking provided along the length to facilitate identification of tube position",
      "Pilot balloon to check inflation & deflation of cuff",
      "Available with DEHP free Material",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-64",
    title: "Ambu Bags",
    Description: [
      "Hand operated, compressible self refilling ventilation bag with non-rebreathing patient valve with pressure limitation valve to minimize the risk of over inflating, intake valve with nipple for oxygen tubing",
      "Supplied with oxygen reservoir bag (suitable capacity) and 2 meter oxygen tubing",
      "Resuscitator can be disassembled for cleaning, disinfecting or autoclaving process",
      "Size : Adult, Paediatric & Neonatal"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-65",
    title: "Suction Catheter Closed System",
    Description: [
      "Used to mainitain ventilation and oxygen therapy while suctioning in mechanically ventilated patients",
      "Minimises the risk of Ventillator Associated Pnemonia (VAP)",
      "Kit comes with 3 easily replaceable catheters, minimizing the need to replace entire suction system every 24-72 hrs",
      "Catheter with lateral eyes, smooth tip and depth markings for maximum patient comfort",
      "MDI port provides an effective, quick and convenient way of drug delivery",
      "Irrigation port with one way valve allows lavage and irrigation of the suction catheter",
      "On/off valve allows suction catheter tip to be isolated and creates an enclosed cleaning chamber",
      "Transparent connectors and durable sleeve facilitates catheter manipulation and prevents infiltration of blood and sputum",
      "360° swivel elbow enables rotation for enhanced patient comfort and reduces torque",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-66",
    title: "Epidural Needle",
    Description: [
      "Highly suitable for Epidural Anaesthesia",
      "Markings on the needle at every 10 mm distance from tip making it easy to observe and also control the exact depth of insertion. Tuohy type needle tip with fixed wings",
      "Clear polycarbonate hub enables visualization of Cerebro Spinal Fluid (CSF) or blood easily",
      "Polished inner bevel minimizes the risk of catheter shearing",
      "Standard Length : 80mm",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-67",
    title: "Epidural Catheter",
    Description: [
      "Epidural Catheter is specially designed for short term & long term continuous anaesthesia & pain therapy",
      "Catheter is made from unique plasticizer - free, latex - free formulation of polymer with excellent bio compatibility",
      "Flexible & atraumatic soft tip with three lateral eyes reduces the risk of complications",
      "Catheter is printed to determine the depth of insertion & accurate placement of catheter in the Epidural space",
      "Crystal clear catheter with radio opaque line provides clear visualization of blood / CSF",
      "Luer lock twist connector is supplied for easy & safe connection",
      "Tube Length : 80 cms",
      "Sizes: Passes through G 16,18 needle. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Anaesthesia"
  },
  {
    id: "med-68",
    title: "Close Wound Suction Unit",
    Description: [
      "Suitable to offer surgeons and doctors an effective device for dosed wound drainage under negative pressure post operatively with the option to use one catheter or two catheters simultaneously",
      "Super smooth kink resistance tubing enables uniform flowrate",
      "Radon drains catheters are provided with radio opaque line and satin smooth eyes",
      "Connecting tube is kink resistant and is provided with additional strength to withstand the suction",
      "Easy to use by one person depress the chamber to active the suction of bellow unit",
      "Available in different sizes with matching size curved needle to meet moderate to heavy drainage needs",
      "X-ray opaque line provided throughout the length of Tube",
      "Connecting tube with clamp &\" Y\" connector, curved needle with matching catheter & spare perforated catheter",
      "Available with DEHP Free Material",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Surgery"
  },
  {
    id: "med-69",
    title: "Mini Close Wound Suction Unit",
    Description: [
      "Baby Vac Set has been specially designed for Wound Drainage under negative pressure for minor surgery and plastic surgery",
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Easy to use Catheter to connect bellow container",
      "Catheters are available in two sizes with matching size curved needle",
      "Frozen surface Catheter and smooth round eyes facilitate efficient drainage",
      "X-ray opaque line provided throughout the length of Tube",
      "Curved Needle with matching catheter Available with DEHP Free Material",
      "Sterile/ Disposable/ Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Surgery"
  },
  {
    id: "med-70",
    title: "Chest Drainage Catheter",
    Description: [
      "Specially designed for rapid non operative pleural and chest drainage",
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Catheter without Trocar: Atraumatic, soft rounded. Open Distal end with six lateral eyes for non-traumatic insertion",
      "Catheter With Trocar: Atraumatic, soft rounded, Open Distal end with two lateral eyes for non-traumatic insertion",
      "Cross side eyes to prevent tissue aspiration",
      "Large smooth drainage eyes for efficient drainage",
      "Proximal end is fitted with tapered connector for easy connection to drainage bottle",
      "X-ray opaque line provided throughout the length of catheter"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Surgery"
  },
  {
    id: "med-71",
    title: "Chest Drainage Bottle",
    Description: [
      "Chest Drainage Bottle is a single use disposable unit which is designed to forward the collected Drainage into a collection chamber by the liquid static suction effects",
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Makes it easy to observe and measure the collected drainage content during surgery",
      "Facilitates safe Retrograde Technique",
      "Product is suitable for pleural drainage in conjunction with chest drainage catheter in Cardiac and Thoracic procedures",
      "Easy to read graduation helps to determine the drain volume precisely",
      "Product Is provided with hanging at a higher position as compares to the common collection chamber allowing the collection of drainage without giving rise to any inconvenience",
      "Suction port is provided to connect with suction unit",
      "Easy to read graduation helps to determine the drain volume precisely",
      "Available with DEHP Free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Surgery"
  },
  {
    id: "med-72",
    title: "Chest Drainage Kit",
    Description: [
      "Kit Includes all the essentials to perform chest drainage and permit the safe mobilisation of patients when under water seals cannot be established or are not practical",
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Ambulatory Chest Drainage System with integral tubing",
      "Available with DEHP Free Material",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Surgery"
  },
  {
    id: "med-73",
    title: "Abdominal Drain Kit",
    Description: [
      "Specially designed for post operative abdominal drainage",
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Soft abdominal drainage catheter with collection bag of 2000 ml. capacity",
      "Catheter is Atraumatic, soft rounded, Open Distal end with six lateral eyes for non-traumatic insertion",
      "X-ray opaque line provided throughout the length of catheter",
      "Specially designed handle holds tube up right and facilitates carrying",
      "Transparent sheeting allows visual inspection",
      "Available with DEHP Free Material",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Surgery"
  },
  {
    id: "med-74",
    title: "Under Water Sealed Drainage Bag",
    Description: [
      "Under water seal drainage system for collection of drainage fluid from thoracic cavity",
      "Super smooth kink resistance tube provided with universal tapered connector",
      "PVC drainage bag with 1000 ml capacity suitable for most thoracic applications",
      "Specially designed moulded handle for easy carrying and hanging of the bag",
      "Clearly marked initial level ensures the under water seal",
      "Transparent sheeting allows visual inspection",
      "Available with DEHP Free Material. Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Surgery"
  },
  {
    id: "med-75",
    title: "Redon Drain Catheter",
    Description: [
      "Provided with radio-opaque line and smooth eyes",
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Markings on the tube at 19 cms from the distal tip",
      "Provided with radio-opaque line and smooth eyes",
      "Cross perforated length of tube: 14 cm",
      "Available with DEHP Free Material",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Surgery"
  },
  {
    id: "med-76",
    title: "Biopsy Needle",
    Description: [
      "Safe & painless percutaneous insertion & penetration",
      "Reduce tissue shear",
      "Provides a clear path to work through when performing multiple biopsies in the same area. Echogenic markings on cannula allow for precise ultrasound placement & centimeter depth markings assist in needle placement",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Surgery"
  },
  {
    id: "med-77",
    title: "Bone Marrow Biopsy Needle",
    Description: [
      "Ergonomic handle",
      "Remover guide provided with indicators to facilitate the sample expulsion and to be able to check the length of the sample during the procedure",
      "The \"MM\" and \"MF\" additional extraction cannulas allow to get the sample in a completely atraumatic and safe way and to hold it without any damage to its surface and inner structure until extraction",
      "Available in Trocar, Aspiration or Fish Mouth tip. Luer Lock connection for syringe",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Surgery"
  },
  
  {
    id: "med-78",
    title: "Skin Stapler",
    Description: [
      "Our special designed and manufactured disposable skin stapler is the specific instrument for surgical skin suture. Our skin stapler has the advantages of quick speed of sewing up during the operation, very less histological reaction, good wound matching and healing, small surgical scar, and no pain for removing, etc. Our disposable skin stapler enables you not to only work with higher efficiency, but also avoid cross-infection effectively. Sterile / Disposable / Individually Packed",
      "Simple and Superior design, easy to operate. Staples are made of High Quality 317L Stainless Steel for medical use",
      "High sewing up and stapling speed help to shorten the time of sewing and avoid the cross infection of many contagious diseases",
      "Less tissue reaction, much thinner scar after operation, and cure faster",
      "Painless and convenient when remove staples after the operation incision healed up"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Surgery"
  },
  {
    id: "med-79",
    title: "Stapler Remover",
    Description: [
      "Our designed Remover for skin stapler is specially used for the removing of skin staples with the feature easy structure and novel appearance",
      "Sterile / Disposable / Individually Packed",
      "Simple and Superior design, easy and fast remove",
      "Remove both of our regular and wider size skin stales. Save handle time and remove with no pain"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Surgery"
  },
  {
    id: "med-80",
    title: "Ryle's Tube",
    Description: [
      "Suitable for nasogastric insertion for nutritional purposes or aspiration of intestinal secretion",
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Atraumatic, soft rounded, closed tip with four lateral eyes for efficient aspiration & administration",
      "The tube is marked at 50,60 & 70cm from the tip for accurate placement",
      "Proximal end is fitted with universal funnel shaped connector for extension",
      "Color coded connectors for easy identification of size as per standards",
      "X-Ray opaque line provided through out the length of Tube",
      "Available with DEHP Free Material",
      "Available with universal luer Connector",
      "Tube Length : 105cm",
      "Sterile / Disposable / Individual Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Gastroenterology"
  },
  {
    id: "med-81",
    title: "Stomach Tube",
    Description: [
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Atraumatic, soft rounded, closed tip with four lateral eyes for efficient aspiration & administration",
      "Tube is marked at 45, 55, 65 and 75 cm from the tip for accurate placement",
      "Proximal end is fitted with universal funnel shaped connector for extension",
      "Color coded connectors for easy identification of size as per standards",
      "X-Ray opaque line provided through out the length of Tube",
      "Available with DEHP Free Material",
      "Available with universal luer Connector",
      "Open Distal end or closed distal end",
      "Tube Length : 105cm",
      "Sterile / Disposable / Individual Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Gastroenterology"
  },
  {
    id: "med-82",
    title: "Levin's Tube",
    Description: [
      "Suitable for gastro intestinal feeding & aspiration",
      "Super smooth kink resistance tubing ensures uniform flow/rate",
      "Atraumatic, soft rounded, closed tip with four lateral eyes for efficient aspiration & administration",
      "Tube is marked at 45,55,65 and 75 cm from the tip for accurate placement",
      "Proximal end is fitted with universal funnel shaped connector for extension",
      "Color coded connectors for easy identification of size as per standards",
      "Available with DEHP Free Material",
      "Available with universal luer Connector",
      "Tube Length: 125 cm",
      "Sterile / Disposable / Individual Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Gastroenterology"
  },
  {
    id: "med-83",
    title: "Infant Feeding Tube",
    Description: [
      "For neonatal and paedlatrlc nutritional feeding",
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Atraumatic, soft rounded, closed tip with two lateral eyes for efficient aspiration & administration",
      "Proximal end is fitted with female luer mount for easy connection to feeding funnel or syringe",
      "Color coded connectors for easy identification of size as per standards",
      "Tube is marked at 20cm away from the distal tip",
      "X-Ray opaque line provided through out the length of Tube",
      "Available with graduation mark after every cm",
      "Available with DEHP Free Material",
      "Tube Length : 52cm",
      "Sterile / Disposable / Individual Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Gastroenterology"
  },
  {
    id: "med-84",
    title: "Colostomy Kit",
    Description: [
      "The colostomy kit gives perfect relief and comfort during prolonged use",
      "It is light weight, flexible and the belting arrangement fits the body well",
      "15mm 'IT form padding is provided between the sleeve and main body for better comfort",
      "Non-Sterile / Individually packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Gastroenterology"
  },
  {
    id: "med-85",
    title: "Yankauer Suction Set",
    Description: [
      "Yankaur Suction Set is suitable for convenient removal of secretion, blood and debris etc per operatively",
      "Complete set is provided with Yankaur Suction Tip mounted on two meter long ribbed tube provided with Universal connector at both ends",
      "Universal connectors are moulded from soft PVC, so as to accommodate the Suction tip on one end and all type of connectors of suction apparatus at the other end",
      "Ribbed tube is kink resistant and has the strength to withstand the suction",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Gastroenterology"
  },
  {
    id: "med-86",
    title: "Umbilical Catheter",
    Description: [
      "Designed for intermittent or continuous access to the umbilical artery or vein of newly born or premature infants",
      "Super smooth kink resistance tubing ensures uniform flowrate",
      "Smooth round tip helps easy cannulation and silk finish surface further facilitates the passage of catheter into the vein",
      "Open distal end without lateral eyes, eliminates the chance of clot formation in the blind spaces",
      "X-Ray opaque line provided through out the length of Tube",
      "Clear scale marking at every cm helps to ascertain depth of insertion",
      "Proximal end is fitted with female luer mount for convenient connection to I.V. therapy equipment",
      "Sterile / Disposable / Individually packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Gastroenterology"
  },
  {
    id: "med-87",
    title: "Karman Cannula",
    Description: [
      "Specially designed for aseptic medical termination of pregnancy",
      "Distal end is coned with two large lateral eyes to facilitates the curette",
      "Suitable for use with MTP syringe or suction apparatus",
      "With or Without universal adopter for connecting to suction apparatus. Sterile / Disposable / Individual Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Miscellaneous"
  },
  {
    id: "med-88",
    title: "Umbilical Cord Clamp",
    Description: [
      "Suitable for clamping the umbilical cord of new born baby immediately after the birth",
      "Provided with double purpose security lock click to indicate the correct locking and protect against accidental reopening",
      "Finger grip ensures safe and convenient handling, particularly when gloves are wet",
      "Provided with grooves all along the length to prevent the sliping of the umbilical cord and to retain it in the same position",
      "Supplied in Blue and White colors, other colors are available upon demand",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Miscellaneous"
  },
  {
    id: "med-89",
    title: "Corrugated Drainage Sheet",
    Description: [
      "Extra soft super smooth PVC corrugated sheet for wound drainage",
      "X-ray opaque line provided throughout the length of sheet",
      "Multi channel drainage system of efficient drainage during operation",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Miscellaneous"
  },
  {
    id: "med-90",
    title: "Disposable Cap",
    Description: [
      "Manufactured from soft non-woven cloth",
      "Specially designed to protect the patient against dropping of hair / dandruff of the doctors and other attending staff",
      "Provided with stitched Interlocking adaptable elastic for better grip on the forehead and comfortable fitting. Sterile or Non-Sterile"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Miscellaneous"
  },
  {
    id: "med-91",
    title: "Disposable Face Mask",
    Description: [
      "Manufactured from soft non-woven cloth",
      "Double layer mask offering excellent bacterial filtration efficiency",
      "Super smooth soft ultrasonically welded mask is most comfortable during use",
      "Tie On or Ear loop type. Sterile or Non-Sterile"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Miscellaneous"
  },
  {
    id: "med-92",
    title: "Infant Mucus Extractor",
    Description: [
      "Specially designed for aspiration of secretion from Oropharynx in newly born babies to ensure free aspiration",
      "Clear transparent container permits immediate visual examination of the aspirate",
      "Also suitable for obtaining mucus specimen for micro biological examination",
      "Spare closure cap is provided to seal the container for safe transportation of specimen to the laboratory or aseptic disposal of container",
      "Low friction surface catheter is provided with open end silk smooth round tip for trauma free insertion",
      "Capacity 20 to 25ml",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Miscellaneous"
  },
  {
    id: "med-93",
    title: "Sputum Cup",
    Description: [
      "Made from Polypropylene",
      "These cups can be alternatively used as urine, excrement or other specimen containers",
      "With good manufacturing techniques",
      "Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Miscellaneous"
  },
  {
    id: "med-94",
    title: "Bed Pan",
    Description: [
      "The bedpan series comes in attractive designs made to be more comfortable and practical than traditional ones",
      "It is made from tough, high grade plastic and is economically designed for utmost human comfort, durable for repeated use, easy to clean and store and suitable for children & adults",
      "Disposable / Available in packs of One, Two & Five nos"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Miscellaneous"
  },
  {
    id: "med-95",
    title: "Urine Pot",
    Description: [
      "Easy fit cover for Hygiene and Odourless, Easy carry handle",
      "Can be stored in standing or lying position",
      "Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Miscellaneous"
  },
  {
    id: "med-96",
    title: "Urine Culture Bottle",
    Description: [
      "Specially designed for collection of urine sample for culture test. Made from crystal clear plastic for clear viewing",
      "Made from Medical grade Polypropylene",
      "Absolutely Leak proof",
      "Sterile / Disposable / Individually Packed"
    ],
    Completeset: [],
    image: "/placeholder.svg",
    category: "Miscellaneous",
  },
];

