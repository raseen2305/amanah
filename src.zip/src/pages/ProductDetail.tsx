import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { medicalProducts } from "./MedicalProducts"; // adjust the path
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { motion } from "framer-motion";

const ProductDetail = () => {
  const { id } = useParams();
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const found = medicalProducts.find((p) => p.id === id);
    if (found) {
      setProduct(found);
    }
    setLoading(false);
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow pt-24 pb-20 flex items-center justify-center">
          <div className="animate-pulse flex flex-col items-center">
            <div className="w-64 h-6 bg-gray-200 rounded mb-4"></div>
            <div className="w-40 h-4 bg-gray-200 rounded"></div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow pt-24 pb-20">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-3xl font-bold text-gray-800 mb-4">Product Not Found</h1>
            <p className="text-gray-600 mb-8">The product you're looking for doesn't exist.</p>
            <Link to="/">
              <Button>Return to Homepage</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow pt-24 pb-20">
        <div className="container mx-auto px-4">
          <div className="flex items-center mb-8">
            <Link to="/medical-products" className="group flex items-center text-pharma-blue hover:opacity-80 transition-colors">
              <ArrowLeft className="h-4 w-4 mr-2 group-hover:-translate-x-1 transition-transform" />
              Back to Medical Products
            </Link>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="bg-white rounded-xl shadow-lg overflow-hidden"
          >
            <div className="md:flex">
              <div className="md:w-1/2 bg-gray-100">
                <div className="h-full flex items-center justify-center p-8">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.title}
                    className="object-contain max-h-[500px] w-full rounded-lg shadow-md"
                  />
                </div>
              </div>

              <div className="md:w-1/2 p-8">
                <h1 className="text-3xl font-bold text-gray-800 mb-4">{product.title}</h1>

                <div className="mb-6">
                  <h2 className="text-xl font-semibold text-gray-800 mb-2">Description</h2>
                  <ul className="list-disc pl-5 space-y-1 text-gray-600">
                    {product.Description?.map((item: string, index: number) => (
                      <li key={index}>{item}</li>
                    ))}
                  </ul>
                </div>

                {product.Completeset?.length > 0 && (
                  <div className="mb-6">
                    <h2 className="text-xl font-semibold text-gray-800 mb-2">Complete Set</h2>
                    <ul className="list-disc pl-5 space-y-1 text-gray-600">
                      {product.Completeset.map((item: string, index: number) => (
                        <li key={index}>{item}</li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="mt-6">
                  <Button className="bg-pharma-blue hover:bg-pharma-blue/80">
                    Request Information
                  </Button>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ProductDetail;
